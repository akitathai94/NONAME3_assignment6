package wci.intermediate;

/**
 * <h1>TypeForm</h1>
 *
 * <p>The interface for a type specification form.</p>
 *
 * <p>Copyright (c) 2008 by Ronald Mak</p>
 * <p>For instructional purposes only.  No warranties.</p>
 */
public interface TypeForm
{
}
